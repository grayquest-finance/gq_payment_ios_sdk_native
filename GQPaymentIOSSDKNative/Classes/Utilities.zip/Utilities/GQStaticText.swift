//
//  GQStaticText.swift
//  GQPaymentIOSSDKNative
//
//  Created by valentine on 01/03/24.
//

import Foundation

enum GQStaticText {
    
    static let mobileNumberPlaceholder = "Enter mobile number"
    
    
    
    
}
